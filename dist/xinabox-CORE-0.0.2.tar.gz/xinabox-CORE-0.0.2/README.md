# Python-CORE
I2C Core for CC03/CS11/CW03, CW02, CW01, Raspberry Pi and Microbit
